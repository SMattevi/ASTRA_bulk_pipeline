:code:`hap_aligner.sh`
======================

blah
