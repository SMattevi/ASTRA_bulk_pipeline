:code:`fetch_haplotype`
=======================
