:code:`process_asts`
====================
